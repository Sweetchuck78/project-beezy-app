// colors.js
export default {
  primary: '#9FC131',
  secondary: '#005C53',
  background: '#F8F8F8',
  text: '#333333',
  border: '#CCCCCC',
  error: '#FF3B30',
  buttonPrimary: '#005C53',
  accentBackground: '#DBF227',
  white: '#FFFFFF',
  dark: '#232323',
  yellow: '#DBF227',
};
